import Foundation
import UIKit
import AVFoundation
import Vision

public class RecyclingViewController: UIViewController {
    
    //MARK: Properties
    private let margin: CGFloat = 75
    private let textSize: CGFloat = 32
    private let raceTime: TimeInterval = 120.0
    private let showHintTime: TimeInterval = 0.2
    
    var captureSession: AVCaptureSession?
    var previewLayer: AVCaptureVideoPreviewLayer?
    var cameraPreviewView: UIView!
    var detectedViews: [DetectionView] = []
    var classifier: VNCoreMLModel!
    var objectsFoundTitle: UILabel!
    var objectsFoundLabel: UITextView!
    var raceTimer: CircularTimer!
    var isGameRunning: Bool = false
    var hintButton: UIButton?
    var hintView: UIView?
    
    /*var debugLabel: UILabel!
    var debugImage: UIImageView!*/
    
    public var typeToFind: Constants.RecyclingTypes = .recyclable
    var objectsFound: [String] = []
    
    public convenience init(recyclingType: Constants.RecyclingTypes) {
        self.init()
        typeToFind = recyclingType
    }
    
    public override func viewDidLoad() {
        cameraPreviewView = UIView(frame: view.bounds)
        cameraPreviewView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        cameraPreviewView.backgroundColor = .black
        view.addSubview(cameraPreviewView)
        
        /*
         // Debug stuff
        debugLabel = UILabel(frame: view.bounds)
        debugLabel.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        debugLabel.textAlignment = .center
        view.addSubview(debugLabel)
        debugImage = UIImageView(frame: CGRect(x: 0, y: 0, width: 224, height: 224))
        debugImage.contentMode = .scaleToFill
        debugImage.backgroundColor = .white
        view.addSubview(debugImage)
         */
        
        classifier = try? VNCoreMLModel(for: RecycleNet().model)
        
        setupCaptureSession()
        startGame()
    }
    
}

// MARK: AVCaptureVideoDataOutputSampleBufferDelegate methods

extension RecyclingViewController: AVCaptureVideoDataOutputSampleBufferDelegate {
    public func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        if !isGameRunning {
            return
        }
        // Saliency analysis
        guard let pixelBuffer: CVPixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        guard let salientObjects = saliencyAnalysis(pixelBuffer: pixelBuffer) else { return }
        
        // Classification
        let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
        let cgImage = convertCIToCGImage(ciImage: ciImage)!
        var classifications: [VNClassificationObservation] = []
        var screenSpaceBoundingBoxes: [CGRect] = []
        for object in salientObjects {
            let boundingBox = invertY(rect: object.boundingBox, source: CGRect(x: 0, y: 0, width: 1, height: 1)) // We need to invert the bouding box
            let modelInput = getModelInput(baseImage: cgImage, salientObjectBoundingBox: boundingBox)
            /*
            // Debug code
            DispatchQueue.main.async {
                self.debugImage.image = UIImage(cgImage: modelInput)
            }
            */
            let classification = runInference(image: modelInput)!
            let screenSpaceBoundingBox = getScreenSpaceBoundingBox(salientObjectBoundingBox: boundingBox, cameraAspect: CGFloat(cgImage.width) / CGFloat(cgImage.height))
            classifications.append(classification)
            screenSpaceBoundingBoxes.append(screenSpaceBoundingBox)
        }
        
        // Update UI
        updateDetectionViews(classifications: classifications, boundingBoxes: screenSpaceBoundingBoxes)
        
        if !isGameRunning {
            DispatchQueue.main.async {
                self.teardownGameViews()
            }
        }
    }
    
    private func getDevice(isFront: Bool = false) -> AVCaptureDevice? {
        // Find available cameras
        var availableDevices: [AVCaptureDevice] = []
        if isFront {
            availableDevices = AVCaptureDevice.DiscoverySession(deviceTypes: [.builtInWideAngleCamera, .builtInDualCamera, .builtInTrueDepthCamera], mediaType: AVMediaType.video, position: .front).devices
        } else {
            availableDevices = AVCaptureDevice.DiscoverySession(deviceTypes: [.builtInWideAngleCamera, .builtInDualCamera, .builtInTrueDepthCamera], mediaType: AVMediaType.video, position: .back).devices
        }
        // Get the first camera
        if let captureDevice = availableDevices.first {
            return captureDevice
        } else {
            return nil
        }
    }
    
    private func setupCaptureSession() {
        let captureSession = AVCaptureSession()
        
        do {
            if let device = getDevice(isFront: false) {
                captureSession.addInput(try AVCaptureDeviceInput(device: device))
            } else {
                print("Camera unavailable.")
            }
        } catch {
            print("Camera unavailable.")
        }
        
        // Set up the capture output
        let captureOutput = AVCaptureVideoDataOutput()
        captureSession.addOutput(captureOutput)
        let previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.videoGravity = .resizeAspectFill
        // No way of knowing orientation in playgrounds, so landscape right by default
        previewLayer.connection?.videoOrientation = AVCaptureVideoOrientation.landscapeRight
        self.previewLayer = previewLayer
        cameraPreviewView.layer.addSublayer(previewLayer)
        previewLayer.frame = cameraPreviewView.frame
        
        // Start the video
        captureOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        captureSession.startRunning()
        
        self.captureSession = captureSession
    }
}

// MARK: Functions for running inference

extension RecyclingViewController {
    
    private func saliencyAnalysis(pixelBuffer: CVPixelBuffer) -> [VNRectangleObservation]? {
        //  We call the saliency analysis
        let saliencyRequest = VNGenerateObjectnessBasedSaliencyImageRequest()
        
        // We run the request and get our saliency regions
        try? VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:]).perform([saliencyRequest])
        return (saliencyRequest.results?.first as? VNSaliencyImageObservation)?.salientObjects
    }
    
    private func runInference(image: CGImage) -> VNClassificationObservation? {
        let inferenceRequest = VNCoreMLRequest(model: classifier)
        try? VNImageRequestHandler(cgImage: image, options: [:]).perform([inferenceRequest])
        guard let inferenceResults = inferenceRequest.results as? [VNClassificationObservation] else { return nil }
        return inferenceResults.first
    }
    
    private func expandToAspectRatio(rect: CGRect, aspectRatio: CGFloat) -> CGRect{
        let originalAspect = rect.width / rect.height
        var width = rect.width
        var height = rect.height
        // So if the original aspect is larger than the desired aspect then the rect is wider than it is supposed to be and
        // height should be increased, and vice versa
        if originalAspect > aspectRatio {
            height = width / aspectRatio
        } else {
            width = height * aspectRatio
        }
        return CGRect(x: rect.midX - width/2, y: rect.midY - height/2, width: width, height: height)
    }
    
    private func rectToSquare(rect: CGRect) -> CGRect {
        return expandToAspectRatio(rect: rect, aspectRatio: CGFloat(1))
    }
    
    private func getImageRegion(rect: CGRect, parentRect: CGRect) -> CGRect {
        // So we take in a rect with coordinates from 0 to 1 and we convert that into a rect which corresponds to the co-ordinates of an image defined in imageRect
        return CGRect(x: rect.minX * parentRect.width + parentRect.minX,
                      y: rect.minY * parentRect.height + parentRect.minY,
                      width: rect.width * parentRect.width,
                      height: rect.height * parentRect.height)
    }
    
    // Inverts a rectangle from normal co-ordinates to CIImage co-ordinates
    private func invertY(rect: CGRect, source: CGRect) -> CGRect {
        return CGRect(x: rect.minX, y: source.height - rect.maxY, width: rect.width, height: rect.height)
    }
    
    private func convertCIToCGImage(ciImage: CIImage) -> CGImage? {
        let context = CIContext(options: nil)
        return context.createCGImage(ciImage, from: ciImage.extent)
    }
    
    private func resizeCGImage(input: CGImage, width: Int, height: Int) -> CGImage? {
        guard let colorSpace = input.colorSpace else { return nil }
        guard let context = CGContext(data: nil, width: Int(width), height: Int(height), bitsPerComponent: input.bitsPerComponent, bytesPerRow: input.bytesPerRow, space: colorSpace, bitmapInfo: input.alphaInfo.rawValue) else { return nil }
        
        // draw image to context (resizing it)
        context.interpolationQuality = .default
        context.draw(input, in: CGRect(x: 0, y: 0, width: width, height: height))
        
        // extract resulting image from context
        return context.makeImage()
    }

    private func resizeModelInput(input: CGImage) -> CGImage? {
        return resizeCGImage(input: input, width: 224, height: 224)
    }
    
    private func getModelInput(baseImage: CGImage, salientObjectBoundingBox: CGRect) -> CGImage {
        let cropRegion = getImageRegion(rect: salientObjectBoundingBox, parentRect: CGRect(x: 0, y: 0, width: baseImage.width, height: baseImage.height))
        let squareCropRegion = rectToSquare(rect: cropRegion)
        let croppedImage = baseImage.cropping(to: squareCropRegion)!
        return self.resizeModelInput(input: croppedImage)!
    }
    
    private func getScreenSpaceBoundingBox(salientObjectBoundingBox: CGRect, cameraAspect: CGFloat) -> CGRect {
        var screenFrame: CGRect!
        DispatchQueue.main.sync {
            screenFrame = cameraPreviewView.frame
        }
        let screenFrameExpanded = expandToAspectRatio(rect: screenFrame, aspectRatio: cameraAspect)
        let screenRegion = getImageRegion(rect: salientObjectBoundingBox, parentRect: screenFrameExpanded)
        let squareScreenRegion = rectToSquare(rect: screenRegion)
        return squareScreenRegion
    }
    
    private func generateLabel(classification: VNClassificationObservation) -> String {
        return "\(classification.identifier), with confidence \(classification.confidence)"
    }
    
    private func updateDetectionViews(classifications: [VNClassificationObservation], boundingBoxes: [CGRect]) {
        // Create mutable versions so we can remove them
        var classificationsMutable = classifications
        var boundingBoxesMutable = boundingBoxes
        DispatchQueue.main.async {
            for (i, view) in self.detectedViews.enumerated().reversed() {
                // First, we need to iterate over the views and remove their possessions of classifications
                view.hasClassification = false
                // Then we attempt to update each view with the classification
                for (j, boundingBox) in boundingBoxesMutable.enumerated().reversed() {
                    let success = view.attemptToAssignClassification(boundingBox: boundingBox, classification: classificationsMutable[j], parent: self)
                    if success {
                        // We break and remove the taken classifications and move onto the next stage
                        classificationsMutable.remove(at: j)
                        boundingBoxesMutable.remove(at: j)
                        break
                    }
                }
                // If there are no matching classifications then we remove the view
                if !view.hasClassification {
                    view.removeFromSuperview()
                    self.detectedViews.remove(at: i)
                }
            }
            // Finally, we still have leftover classifications which were not assigned to anything. So we add new views for them
            for (i, boundingBox) in boundingBoxesMutable.enumerated() {
                let detectionView = DetectionView(frame: boundingBox, classification: classificationsMutable[i], parent: self)
                self.view.addSubview(detectionView)
                self.detectedViews.append(detectionView)
            }
        }
    }
    
}

// MARK: Functions that handle game events
public extension RecyclingViewController {
    
    private func setupGameViews() {
        let tintColor = Constants.colors[Constants.recyclingColors[typeToFind]!]
        
        objectsFoundTitle = UILabel(frame: CGRect(x: 0, y: margin, width: view.bounds.width - margin, height: 40))
        objectsFoundTitle.textAlignment = .right
        objectsFoundTitle.textColor = tintColor
        objectsFoundTitle.text = "Objects found:"
        objectsFoundTitle.font = UIFont.systemFont(ofSize: textSize, weight: .bold)
        view.addSubview(objectsFoundTitle)
        
        objectsFoundLabel = UITextView(frame: CGRect(x: 0, y: margin + 40, width: view.bounds.width - margin, height: view.bounds.height - 80 - margin*2))
        objectsFoundLabel.textAlignment = .right
        objectsFoundLabel.textColor = Constants.colors["white"]
        objectsFoundLabel.font = UIFont.systemFont(ofSize: textSize, weight: .bold)
        objectsFoundLabel.backgroundColor = UIColor.clear
        objectsFoundLabel.isEditable = false
        view.addSubview(objectsFoundLabel)
        
        let raceTimerFrame = CGRect(x: margin, y: margin, width: 150, height: 150)
        raceTimer = CircularTimer(frame: raceTimerFrame, strokeWidth: 20, duration: raceTime, progressColor: tintColor!, trackColor: Constants.colors["gray"]!, backgroundColor: Constants.colors["white"]!, completionHandler: gameOver, countdown: true)
        let raceLabel = UILabel(frame: raceTimer.bounds)
        raceLabel.font = UIFont.systemFont(ofSize: 72, weight: .bold)
        raceLabel.textColor = tintColor
        raceLabel.text = "\(Int(raceTime))"
        raceLabel.textAlignment = .center
        raceLabel.adjustsFontSizeToFitWidth = true
        var timeCounter = Int(raceTime)
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { timer in
            timeCounter -= 1
            if timeCounter <= 0 {
                timer.invalidate()
            }
            raceLabel.text = "\(timeCounter)"
        }
        raceTimer.addSubview(raceLabel)
        view.addSubview(raceTimer)
        
        let hintButton = UIButton(frame: CGRect(x: margin, y: view.bounds.height - margin - 100, width: 100, height: 100))
        hintButton.layer.cornerRadius = 50
        hintButton.backgroundColor = tintColor
        hintButton.setTitle("?", for: .normal)
        hintButton.titleLabel?.font = UIFont.systemFont(ofSize: 64, weight: .bold)
        hintButton.addTarget(self, action: #selector(showHint(sender:)), for: .touchUpInside)
        hintButton.layer.zPosition = 3
        self.hintButton = hintButton
        view.addSubview(hintButton)
    }
    
    @objc func showHint(sender: UIButton) {
        let tintColor = Constants.colors[Constants.recyclingColors[typeToFind]!]
        let hintView = UIView(frame: CGRect(x: -351, y: margin + 50, width: 350, height: view.bounds.height - margin - 100 - 120))
        hintView.backgroundColor = tintColor
        hintView.layer.cornerRadius = 25
        let scrollView = UIScrollView(frame: hintView.bounds)
        hintView.addSubview(scrollView)
        let label = UILabel(frame: CGRect(x: 25, y: 0, width: scrollView.bounds.width - 25, height: scrollView.bounds.height))
        label.textColor = Constants.colors["white"]
        label.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        var hintText = "\(RecyclingViewController.convertText(label: Constants.recyclingNames[typeToFind]!)) Objects:"
        for objectClass in Constants.objectTypes[typeToFind]! {
            hintText += ("\n"+RecyclingViewController.convertText(label: objectClass))
        }
        label.numberOfLines = 0
        label.autoresizingMask = .flexibleHeight
        label.text = hintText
        label.sizeToFit()
        scrollView.addSubview(label)
        scrollView.contentSize = label.bounds.size
        view.addSubview(hintView)
        sender.isUserInteractionEnabled = false
        UIView.animate(withDuration: showHintTime, animations: {
            hintView.frame = CGRect(x: self.margin, y: self.margin + 50, width: 350, height: self.view.bounds.height - self.margin - 100 - 120)
        }, completion: { (completed: Bool) in
            sender.isUserInteractionEnabled = true
        })
        sender.setTitle("X", for: .normal)
        sender.removeTarget(self, action: #selector(showHint(sender:)), for: .touchUpInside)
        sender.addTarget(self, action: #selector(hideHint(sender:)), for: .touchUpInside)
        self.hintView = hintView
    }
    
    @objc func hideHint(sender: UIButton) {
        if let hintView = hintView {
            sender.isUserInteractionEnabled = false
            UIView.animate(withDuration: showHintTime, animations: {
                hintView.frame = CGRect(x: -301, y: self.margin + 50, width: 300, height: self.view.bounds.height - self.margin - 100 - 120)
            }, completion: { (completed: Bool) in
                hintView.removeFromSuperview()
                self.hintView = nil
                sender.isUserInteractionEnabled = true
            })
            sender.setTitle("?", for: .normal)
            sender.removeTarget(self, action: #selector(hideHint(sender:)), for: .touchUpInside)
            sender.addTarget(self, action: #selector(showHint(sender:)), for: .touchUpInside)
        }
    }
    
    private func teardownGameViews() {
        for view in detectedViews {
            view.removeFromSuperview()
        }
        detectedViews = []
        raceTimer.removeFromSuperview()
        raceTimer = nil
        hintButton?.removeFromSuperview()
        hintButton = nil
        hintView?.removeFromSuperview()
        hintView = nil
    }
    
    private func startGame() {
        let instructionsLabel = UILabel(frame: view.frame)
        let instructionsColor = Constants.colors[Constants.recyclingColors[typeToFind]!]!
        instructionsLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        instructionsLabel.textAlignment = .center
        instructionsLabel.textColor = instructionsColor
        instructionsLabel.numberOfLines = 0
        instructionsLabel.text = "Find as many \(Constants.recyclingNames[typeToFind]!.replacingOccurrences(of: "_", with: " ")) objects as you can in \(Int(raceTime)) seconds!"
        view.addSubview(instructionsLabel)
        let queue: DispatchQueue = DispatchQueue(label: "readyQueue")
        queue.async {
            Thread.sleep(forTimeInterval: 3.0)
            DispatchQueue.main.sync {
                instructionsLabel.text = "Go!"
            }
            Thread.sleep(forTimeInterval: 1.0)
            DispatchQueue.main.sync {
                instructionsLabel.removeFromSuperview()
                self.setupGameViews()
                self.isGameRunning = true
            }
        }
    }
    
    static func convertText(label: String) -> String {
        let newLabel = label.replacingOccurrences(of: "_", with: " ")
        let capitalisedLabel = newLabel.prefix(1).capitalized + newLabel.dropFirst()
        return capitalisedLabel// + "\n"
    }
    
    func addObjectFound(object: String) {
        if !objectsFound.contains(object) {
            objectsFound.append(object)
            print(objectsFound)
            if let text = objectsFoundLabel.text {
                let newText = text + RecyclingViewController.convertText(label: object) + "\n"
                objectsFoundLabel.text = newText
            } else {
                objectsFoundLabel.text = RecyclingViewController.convertText(label: object) + "\n"
            }
        }
    }
    
    func hasFoundObject(object: String) -> Bool {
        return objectsFound.contains(object)
    }
    
    private func gameOver() {
        stopGame()
        print("Game Over! You found \(objectsFound.count) objects!")
    }
    
    private func stopGame() {
        isGameRunning = false
        captureSession?.stopRunning()
        createGameOverView()
    }
    
    private func createGameOverView() {
        let view = UIView(frame: self.view.bounds)
        let tintColor = Constants.colors[Constants.recyclingColors[typeToFind]!]!
        // Blur the view if transparency is enabled
        if !UIAccessibility.isReduceTransparencyEnabled {
            view.backgroundColor = .clear

            let blurEffect = UIBlurEffect(style: .dark)
            let blurEffectView = UIVisualEffectView(effect: blurEffect)
            blurEffectView.frame = view.bounds
            blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            view.addSubview(blurEffectView)
        } else {
            view.backgroundColor = Constants.colors["gray"]
        }
        let titleHeight: CGFloat = 100
        let title = UILabel(frame: CGRect(x: 0, y: margin, width: view.bounds.width, height: titleHeight))
        title.font = UIFont.systemFont(ofSize: 48, weight: .bold)
        title.textAlignment = .center
        title.textColor = tintColor
        title.text = "You Found \(objectsFound.count) \(RecyclingViewController.convertText(label: Constants.recyclingNames[typeToFind]!)) Items!"
        view.addSubview(title)
        let returnButton = UIButton(type: .roundedRect)
        let buttonWidth: CGFloat = 200
        let buttonHeight: CGFloat = 60
        returnButton.frame = CGRect(x: view.bounds.width/2 - buttonWidth/2, y: view.bounds.height - margin*2 - buttonHeight, width: buttonWidth, height: buttonHeight)
        returnButton.layer.cornerRadius = buttonHeight/2
        returnButton.setTitle("Play Again?", for: .normal)
        returnButton.titleLabel?.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        returnButton.tintColor = Constants.colors["white"]
        returnButton.backgroundColor = tintColor
        returnButton.addTarget(self, action: #selector(returnToMenu(sender:)), for: .touchUpInside)
        view.addSubview(returnButton)
        let ranking = getRecyclingRanking(itemsFound: objectsFound.count)
        let rankingView = UIView(frame: CGRect(x: 0, y: margin + titleHeight, width: view.bounds.width/2 , height: view.bounds.height - margin - titleHeight - buttonHeight - margin))
        let rankingTitle = UILabel(frame: CGRect(x: 0, y: 0, width: rankingView.bounds.width, height: 50))
        rankingTitle.textAlignment = .center
        rankingTitle.text = "Ranking: \(ranking.title)"
        rankingTitle.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        rankingTitle.textColor = tintColor
        rankingView.addSubview(rankingTitle)
        let rankingImage = UIImageView(image: UIImage(named: ranking.imageName))
        rankingImage.frame = CGRect(x: 0, y: 50, width: rankingView.bounds.width, height: rankingView.bounds.height - 100)
        rankingImage.contentMode = .scaleAspectFit
        rankingView.addSubview(rankingImage)
        let starSize: CGFloat = 50
        var stars: [UIImageView] = []
        let starsView = UIView(frame: CGRect(x: (rankingView.bounds.width - starSize*5)/2, y: rankingView.bounds.height - starSize, width: starSize*5, height: starSize))
        for i in 0..<5 {
            let star = UIImageView(frame: CGRect(x: CGFloat(i)*starSize, y: 0, width: starSize, height: starSize))
            star.contentMode = .scaleAspectFit
            star.image = UIImage(named: "starfill")?.withRenderingMode(.alwaysTemplate)
            star.tintColor = Constants.colors["white"]
            stars.append(star)
            starsView.addSubview(star)
        }
        starsView.layoutSubviews()
        for i in 0..<ranking.numStars {
            stars[i].tintColor = tintColor
        }
        //rankingView.addArrangedSubview(starsView)
        rankingView.addSubview(starsView)
        view.addSubview(rankingView)
        let itemsFoundTitle = UILabel(frame: CGRect(x: view.bounds.width/2, y: margin + titleHeight, width: view.bounds.width/2, height: 50))
        itemsFoundTitle.text = "Items You Found:"
        itemsFoundTitle.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        itemsFoundTitle.textColor = tintColor
        itemsFoundTitle.textAlignment = .center
        view.addSubview(itemsFoundTitle)
        let itemsFound = UILabel(frame: CGRect(x: view.bounds.width/2, y: margin + titleHeight + 50, width: view.bounds.width/2, height: view.bounds.height - margin + titleHeight + 100))
        itemsFound.text = ""
        for item in objectsFound {
            itemsFound.text?.append(RecyclingViewController.convertText(label: item) + "\n")
        }
        itemsFound.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        itemsFound.numberOfLines = 0
        itemsFound.textAlignment = .center
        itemsFound.autoresizingMask = .flexibleBottomMargin
        itemsFound.textColor = .white
        itemsFound.sizeToFit()
        itemsFound.frame = CGRect(x: itemsFound.frame.minX, y: itemsFound.frame.minY, width: view.bounds.width/2, height: itemsFound.frame.height)
        view.addSubview(itemsFound)
        self.view.addSubview(view)
    }
    
    private func getRecyclingRanking(itemsFound: Int) -> (title: String, numStars: Int, imageName: String) {
        if itemsFound >= 8 {
            return ("Eco Champion", 5, "EcoChampion")
        } else if itemsFound >= 6 {
            return ("Green Guru", 4, "GreenGuru")
        } else if itemsFound >= 3 {
            return ("Sustainability Scholar", 3, "SustainabilityScholar")
        } else {
            return ("Junior Recycler", 2, "JuniorRecycler")
        }
    }
    
    @objc func returnToMenu(sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
}
