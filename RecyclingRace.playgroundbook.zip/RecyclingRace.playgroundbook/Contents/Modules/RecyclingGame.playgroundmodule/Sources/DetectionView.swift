//
//  DetectionView.swift
//  recyclingracetest
//
//  Created by Wenzheng Du on 4/4/21.
//

import Foundation
import UIKit
import Vision

public class DetectionView: UIView {
    
    private let locationThresh: CGFloat = 100
    private let sizeThresh: CGFloat = 0.8
    private let animationSpeed = 0.2
    private let labelHeight: CGFloat = CGFloat(60)
    private let borderWidth = CGFloat(20)
    private let timerSizeRatio = CGFloat(0.5)
    private let timerStrokeWidth = CGFloat(20)
    private let strokeWidthRatio = CGFloat(0.05)
    private let timerDuration: TimeInterval = 1.0
    
    private var lastObject: String = ""
    
    private var objectClass: String = "other"
    
    var uiLabel: UILabel
    var timer: CircularTimer?
    var alreadyFoundLabel: UILabel?
    
    public var hasClassification: Bool
    
    public init(frame: CGRect, classification: VNClassificationObservation, parent: RecyclingViewController){
        uiLabel = UILabel()
        hasClassification = true
        super.init(frame: frame)
        
        isUserInteractionEnabled = false
        
        layer.borderWidth = borderWidth
        
        uiLabel.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        uiLabel.textAlignment = .center
        uiLabel.textColor = Constants.colors["white"]
        uiLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        uiLabel.adjustsFontSizeToFitWidth = true
        
        let objectClass = getObjectClass(classification: classification)
        updateTimer(selfFrame: frame, object: objectClass, parent: parent)
        
        updateViewToClassification(frame: frame, classification: classification, animate: false)
        
        addSubview(uiLabel)
    }
    
    public func attemptToAssignClassification(boundingBox: CGRect, classification: VNClassificationObservation, parent: RecyclingViewController) -> Bool {
        if boundingBoxMatches(boundingBox: boundingBox) {
            hasClassification = true
            updateTimer(selfFrame: boundingBox, object: getObjectClass(classification: classification), parent: parent)
            updateViewToClassification(frame: boundingBox, classification: classification, animate: true)
            return true
        }
        return false
    }
    
    private func boundingBoxMatches(boundingBox: CGRect) -> Bool {
        let dist: CGFloat = sqrt((frame.midX - boundingBox.midX)*(frame.midX - boundingBox.midX) + (frame.midY - boundingBox.midY)*(frame.midY - boundingBox.midY)) // Distance using Pythagorean Theorem
        let sizeRatio: CGFloat = frame.width / boundingBox.width // Assume both are squares
        return (dist < locationThresh) && (sizeThresh < sizeRatio && sizeRatio < 1/sizeThresh)
    }
    
    private func updateViewToClassification(frame: CGRect, classification: VNClassificationObservation, animate: Bool = false) {
        if !animate {
            objectClass = getObjectClass(classification: classification)
            let recyclingType = getRecyclingType(objectClass: objectClass)
            let recyclingColor = Constants.colors[Constants.recyclingColors[recyclingType]!]
            self.frame = frame
            layer.borderColor = recyclingColor?.cgColor
            uiLabel.frame = getLabelFrame(selfFrame: frame)
            uiLabel.backgroundColor = recyclingColor
            uiLabel.text = generateLabel(classification: classification)
            if let alreadyFoundLabel = alreadyFoundLabel {
                alreadyFoundLabel.frame = CGRect(x: frame.width*0.1, y: frame.height*0.1, width: frame.width*0.8, height: frame.height*0.8)
            }
        } else {
            UIView.animate(withDuration: animationSpeed, animations: {
                self.updateViewToClassification(frame: frame, classification: classification)
            })
        }
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func generateLabel(classification: VNClassificationObservation) -> String {
        return "\(RecyclingViewController.convertText(label: getObjectClass(classification: classification))) (Confidence: \(Int(round(classification.confidence*100)))%)"
    }
    
    private func getObjectClass(classification: VNClassificationObservation) -> String {
        return classification.identifier.replacingOccurrences(of: "\\s?\\([^)]*\\)", with: "", options: .regularExpression)
    }
    
    private func getRecyclingType(objectClass: String) -> Constants.RecyclingTypes {
        for type in Constants.RecyclingTypes.allCases {
            if Constants.objectTypes[type]!.contains(objectClass) {
                return type
            }
        }
        return Constants.RecyclingTypes.na
    }
    
    private func getLabelFrame(selfFrame: CGRect) -> CGRect {
        // So the label frame will be at the bottom of the view's own frame and be 1/10 its height
        return CGRect(x: borderWidth-1, y: selfFrame.height - labelHeight, width: selfFrame.width-borderWidth, height: labelHeight)
    }
    
    
    private func getTimerFrame(selfFrame: CGRect) -> CGRect {
        let sideLength = selfFrame.width * timerSizeRatio
        return CGRect(x: selfFrame.width/2 - sideLength/2, y: selfFrame.height/2 - sideLength/2 - labelHeight/4, width: sideLength, height: sideLength)
    }
    
    private func createTimer(selfFrame: CGRect, object: String, parent: RecyclingViewController) {
        let objectType = getRecyclingType(objectClass: object)
        let classColor = Constants.colors[Constants.recyclingColors[objectType]!]!
        let timer = CircularTimer(frame: getTimerFrame(selfFrame: selfFrame), strokeWidth: frame.width*strokeWidthRatio, duration: timerDuration, progressColor: classColor, trackColor: Constants.colors["white"]!, completionHandler: {() -> Void in
            parent.addObjectFound(object: object)
            self.timer?.removeFromSuperview()
            self.createAlreadyFoundLabel(selfFrame: self.frame, object: self.lastObject)
        })
        timer.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(timer)
        self.timer = timer
    }
    
    private func createAlreadyFoundLabel(selfFrame: CGRect, object: String) {
        let objectType = getRecyclingType(objectClass: object)
        let classColor = Constants.colors[Constants.recyclingColors[objectType]!]!
        let alreadyFoundLabel = UILabel(frame: CGRect(x: selfFrame.width*0.1, y: selfFrame.height*0.1, width: selfFrame.width*0.8, height: selfFrame.height*0.8))
        alreadyFoundLabel.textColor = classColor
        alreadyFoundLabel.text = "ALREADY FOUND"
        alreadyFoundLabel.font = UIFont.systemFont(ofSize: 36, weight: .bold)
        alreadyFoundLabel.adjustsFontSizeToFitWidth = true
        alreadyFoundLabel.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        alreadyFoundLabel.textAlignment = .center
        addSubview(alreadyFoundLabel)
        self.alreadyFoundLabel = alreadyFoundLabel
    }
    
    private func updateTimer(selfFrame: CGRect, object: String, parent: RecyclingViewController) {
        if object != lastObject {
            timer?.removeFromSuperview()
            alreadyFoundLabel?.removeFromSuperview()
            let objectType = getRecyclingType(objectClass: object)
            if objectType == parent.typeToFind {
                if parent.hasFoundObject(object: object) {
                    // Implement the "Already Found" feature
                    createAlreadyFoundLabel(selfFrame: selfFrame, object: object)
                } else {
                    createTimer(selfFrame: selfFrame, object: object, parent: parent)
                }
            }
        }
        lastObject = object
    }
    
}
