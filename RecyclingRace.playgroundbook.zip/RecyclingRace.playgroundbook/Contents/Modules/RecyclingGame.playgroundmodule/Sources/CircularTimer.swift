//
//  CircularProgressView.swift
//  recyclingracetest
//
//  Created by Wenzheng Du on 8/4/21.
//

import Foundation
import UIKit

public class CircularTimer: UIView {
    
    private var progressLayer: CAShapeLayer = CAShapeLayer()
    private var trackLayer: CAShapeLayer = CAShapeLayer()
    private var backgroundLayer: CAShapeLayer = CAShapeLayer()
    
    private var completionHandler: () -> Void = {() -> Void in }
    
    public init(frame: CGRect, strokeWidth: CGFloat, duration: TimeInterval, progressColor: UIColor, trackColor: UIColor, backgroundColor: UIColor = UIColor.clear, completionHandler: @escaping () -> Void = {() -> Void in }, countdown: Bool = false) {
        self.completionHandler = completionHandler
        super.init(frame: frame)
        createCircles(strokeWidth: strokeWidth, progressColor: progressColor, trackColor: trackColor, backgroundColor: backgroundColor)
        startAnimation(duration: duration, countdown: countdown, completionHandler: completionHandler)
    }
    
    private func createCircles(strokeWidth: CGFloat, progressColor: UIColor, trackColor: UIColor, backgroundColor: UIColor) {
        let circle = UIBezierPath(arcCenter: CGPoint(x: frame.width / 2.0, y: frame.height / 2.0), radius: frame.width/2, startAngle: -.pi / 2, endAngle: 3 * .pi / 2, clockwise: true)
        backgroundLayer.path = circle.cgPath
        backgroundLayer.fillColor = backgroundColor.cgColor
        trackLayer.path = circle.cgPath
        trackLayer.fillColor = UIColor.clear.cgColor
        trackLayer.lineWidth = strokeWidth
        trackLayer.strokeColor = trackColor.cgColor
        progressLayer.path = circle.cgPath
        progressLayer.fillColor = UIColor.clear.cgColor
        progressLayer.lineWidth = strokeWidth
        progressLayer.lineCap = .round
        progressLayer.strokeColor = progressColor.cgColor
        layer.addSublayer(backgroundLayer)
        layer.addSublayer(trackLayer)
        layer.addSublayer(progressLayer)
    }
    
    private func startAnimation(duration: TimeInterval, countdown: Bool, completionHandler: @escaping () -> Void) {
        let startValue: CGFloat = countdown ? 1 : 0
        let endValue: CGFloat = countdown ? 0: 1
        progressLayer.strokeEnd = startValue
        let animation = CABasicAnimation(keyPath: "strokeEnd")
        animation.duration = duration
        animation.toValue = endValue
        animation.fillMode = .forwards
        animation.isRemovedOnCompletion = false
        animation.delegate = self
        progressLayer.add(animation, forKey: "anim")
    }
    
    public override func removeFromSuperview() {
        progressLayer.removeAllAnimations()
        super.removeFromSuperview()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
}

extension CircularTimer: CAAnimationDelegate {
    public func animationDidStop(_ anim: CAAnimation, finished flag: Bool) {
        if flag {
            completionHandler()
        }
    }
}
