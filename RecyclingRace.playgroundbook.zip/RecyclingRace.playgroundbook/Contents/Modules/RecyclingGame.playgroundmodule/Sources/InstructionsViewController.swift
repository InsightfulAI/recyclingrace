//
//  InstructionsViewController.swift
//  RecyclingGame
//
//  Created by Wenzheng Du on 10/4/21.
//

import Foundation
import UIKit

public class InstructionsViewController: UIViewController {
    
    private let animationSpeed: TimeInterval = 0.5
    private let buttonWidth: CGFloat = 200
    private let buttonHeight: CGFloat = 60
    private let margin: CGFloat = 50
    private let titleHeight: CGFloat = 100
    private var functionsToGenerateViews: [() -> UIView] = []
    
    var currentSlide: UIView?
    var previousSlide: UIView?
    var slideIndex = 0
    var currentGameMode = Constants.GameTypes.recyclable
    
    public override func viewDidLoad() {
        // View did load
        functionsToGenerateViews = [createFirstSlide, createSecondSlide, createThirdSlide, createFourthSlide, createFifthSlide, createSixthSlide]
        currentSlide = createFirstSlide()
        slideIndex = 0
        view.addSubview(currentSlide!)
    }
    
}

// MARK: Functions for initialising the views
extension InstructionsViewController {
    
    private func createSlideView() -> UIView {
        return UIView(frame: view.frame)
    }
    
    private func createParagraph(parentFrame: CGRect) -> UILabel {
        let paragraph = UILabel(frame: CGRect(x: 0, y: 0, width: parentFrame.width, height: 300))
        paragraph.autoresizingMask = .flexibleHeight
        paragraph.textColor = Constants.colors["white"]
        paragraph.numberOfLines = 0
        paragraph.textAlignment = .justified
        paragraph.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        return paragraph
    }
    
    private func createHeading(parentFrame: CGRect) -> UILabel {
        let paragraph = createParagraph(parentFrame: parentFrame)
        paragraph.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        return paragraph
    }
    
    private func adjustVerticalStackViewSize(stackView: UIStackView) {
        // Bunch of hacks to make stackview work without constraints
        stackView.layoutSubviews()
        var totalHeight = CGFloat.zero
        for view in stackView.arrangedSubviews {
            totalHeight += view.bounds.height
        }
        let totalSpace = stackView.spacing * CGFloat(stackView.arrangedSubviews.count - 1)
        stackView.frame = CGRect(x: stackView.frame.minX, y: stackView.frame.minY, width: stackView.frame.width, height: totalHeight + totalSpace)
        // Here is the hackiest hack of them all
        if let scrollView = stackView.superview as? UIScrollView {
            scrollView.contentSize = stackView.bounds.size
        }
    }
    
    private func createInstructionViews()
    -> (slide: UIView, title: UILabel, content: UIStackView, image: UIImageView, prevButton: UIButton, nextButton: UIButton) {
        let slide = createSlideView()
        slide.backgroundColor = Constants.colors["white"]
        let title = UILabel(frame: CGRect(x: 0, y: margin, width: view.bounds.width, height: titleHeight))
        title.font = UIFont.systemFont(ofSize: 48, weight: .bold)
        title.textAlignment = .center
        title.textColor = Constants.colors["white"]
        slide.addSubview(title)
        let image = UIImageView(frame: CGRect(x: margin, y: margin+titleHeight, width: (view.bounds.width - margin*2)/4, height: view.bounds.height - margin*2 - titleHeight*2))
        image.contentMode = .scaleAspectFit
        slide.addSubview(image)
        let scrollView = UIScrollView(frame: CGRect(x: margin + (view.bounds.width - margin*2)/4 + margin, y: margin+titleHeight, width: (view.bounds.width - margin*2)/4*3 - margin, height: view.bounds.height - margin*2 - titleHeight*2))
        
        slide.addSubview(scrollView)
        let contentView = UIStackView(frame: CGRect(x: 0, y: 0, width: scrollView.bounds.width - 20, height: 10000))
        contentView.axis = .vertical
        contentView.alignment = .fill
        contentView.spacing = 10
        contentView.autoresizingMask = .flexibleBottomMargin
        contentView.distribution = .equalSpacing
        scrollView.addSubview(contentView)
        scrollView.showsVerticalScrollIndicator = true // Does not seem to be working?
        scrollView.indicatorStyle = .white
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        let prevButton = UIButton(type: .roundedRect)
        prevButton.frame = CGRect(x: view.bounds.width/4 - buttonWidth/2, y: view.bounds.height - margin - titleHeight/2 - buttonHeight/2, width: buttonWidth, height: buttonHeight)
        prevButton.layer.cornerRadius = buttonHeight/2
        prevButton.setTitle("Previous", for: .normal)
        prevButton.titleLabel?.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        prevButton.tintColor = Constants.colors["gray"]
        prevButton.backgroundColor = Constants.colors["white"]
        prevButton.addTarget(self, action: #selector(retractSlide(sender:)), for: .touchUpInside)
        slide.addSubview(prevButton)
        let nextButton = UIButton(type: .roundedRect)
        nextButton.frame = CGRect(x: view.bounds.width/4*3 - buttonWidth/2, y: view.bounds.height - margin - titleHeight/2 - buttonHeight/2, width: buttonWidth, height: buttonHeight)
        nextButton.layer.cornerRadius = buttonHeight/2
        nextButton.setTitle("Next", for: .normal)
        nextButton.titleLabel?.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        nextButton.tintColor = Constants.colors["gray"]
        nextButton.backgroundColor = Constants.colors["white"]
        nextButton.addTarget(self, action: #selector(advanceSlide(sender:)), for: .touchUpInside)
        slide.addSubview(nextButton)
        return (slide, title, contentView, image, prevButton, nextButton)
    }
    
    private func createFirstSlide() -> UIView {
        let view = createSlideView()
        view.frame = UIScreen.main.bounds
        let posterBackground = UIImageView(image: UIImage(named: "poster"))
        posterBackground.frame = view.bounds
        posterBackground.contentMode = .scaleAspectFill
        view.addSubview(posterBackground)
        let beginButton = UIButton(type: .roundedRect)
        beginButton.frame = CGRect(x: UIScreen.main.bounds.width/2 - buttonWidth/1.5, y: UIScreen.main.bounds.height/2 - buttonHeight/1.5, width: buttonWidth*1.5, height: buttonHeight*1.5)
        beginButton.backgroundColor = Constants.colors["green"]
        beginButton.layer.cornerRadius = buttonHeight*0.75
        beginButton.setTitle("Begin", for: .normal)
        beginButton.titleLabel?.font = UIFont.systemFont(ofSize: 36, weight: .bold)
        beginButton.tintColor = Constants.colors["white"]
        beginButton.addTarget(self, action: #selector(advanceSlide(sender:)), for: .touchUpInside)
        view.addSubview(beginButton)
        return view
    }
    
    private func createSecondSlide() -> UIView {
        let views = createInstructionViews()
        let tintColor = Constants.colors["gray"]
        views.slide.backgroundColor = tintColor
        views.title.text = "How to Play"
        views.image.image = UIImage(named: "EcoChampion")
        let heading1 = createHeading(parentFrame: views.content.bounds)
        heading1.text = "AI-Powered Recycling Game"
        views.content.addArrangedSubview(heading1)
        let paragraph1 = createParagraph(parentFrame: views.content.bounds)
        paragraph1.text = "Find as many recyclable objects (or objects of the type specified) as you can in 120 seconds! The AI will recognise which objects are recyclable and which objects are not recyclable. The more objects you find, the better your recycling rank! Can you become the Eco Champion?"
        views.content.addArrangedSubview(paragraph1)
        let heading2 = createHeading(parentFrame: views.content.bounds)
        heading2.text = "Finding Objects"
        views.content.addArrangedSubview(heading2)
        let paragraph2 = createParagraph(parentFrame: views.content.bounds)
        paragraph2.text = "To find an object, position your camera over it and wait for it to scan. If the object is recognized incorrectly by the AI, then try to adjust your camera angle. Once the object is correctly identified, hold your camera steady for one second and it will be added to the list of objects found."
        views.content.addArrangedSubview(paragraph2)
        let paragraph3 = createParagraph(parentFrame: views.content.bounds)
        paragraph3.text = "You cannot add objects of the same type twice. For example, if you have already found a water bottle, you cannot scan a second water bottle, even if the second water bottle is different to the first one."
        views.content.addArrangedSubview(paragraph3)
        let paragraph4 = createParagraph(parentFrame: views.content.bounds)
        paragraph4.text = "In this game, recyclable objects are indicated by green, non-recyclable objects are indicated by red, and special objects are indicated by yellow. These colors may be different where you live, so always consult your local recycling provider for the most accurate information!"
        views.content.addArrangedSubview(paragraph4)
        views.prevButton.tintColor = tintColor
        views.nextButton.tintColor = tintColor
        adjustVerticalStackViewSize(stackView: views.content)
        return views.slide
    }
    
    private func createThirdSlide() -> UIView {
        let views = createInstructionViews()
        let tintColor = Constants.colors["green"]
        views.slide.backgroundColor = tintColor
        views.title.text = "What is Recyclable?"
        views.image.image = UIImage(named: "SustainabilityScholar")
        let paragraph1 = createParagraph(parentFrame: views.content.bounds)
        paragraph1.text = "Plastic, metal, glass and paper items can all be recycled."
        views.content.addArrangedSubview(paragraph1)
        let heading1 = createHeading(parentFrame: views.content.bounds)
        heading1.text = "Plastics"
        views.content.addArrangedSubview(heading1)
        let paragraph2 = createParagraph(parentFrame: views.content.bounds)
        paragraph2.text = "Plastics such as buckets, plastic bottles, water bottles, measuring cups, and plastic garden pots are recyclable. Soft plastics, such as plastic bags and bubble wrap, are not recyclable."
        views.content.addArrangedSubview(paragraph2)
        let paragraph3 = createParagraph(parentFrame: views.content.bounds)
        paragraph3.text = "Remember to clean plastic products such as bottles and gardening pots before recycling them! Contaminated products can affect the recycling process. Also, remember to separate bottle caps from plastic bottles as they are recycled separately."
        views.content.addArrangedSubview(paragraph3)
        let heading2 = createHeading(parentFrame: views.content.bounds)
        heading2.text = "Glass"
        views.content.addArrangedSubview(heading2)
        let paragraph4 = createParagraph(parentFrame: views.content.bounds)
        paragraph4.text = "Only packaging glass, such as drink bottles and jars, can be recycled. Only clear, green and brown glass is recyclable. Drink glasses as well as heat-treated glass, glass jugs and glass plates cannot be recycled in your curbside recycling bin! However, some recycling facilities may be able to recycle these glass materials."
        views.content.addArrangedSubview(paragraph4)
        let heading3 = createHeading(parentFrame: views.content.bounds)
        heading3.text = "Metal"
        views.content.addArrangedSubview(heading3)
        let paragraph5 = createParagraph(parentFrame: views.content.bounds)
        paragraph5.text = "Metal is infinitely recyclable. Metal cans, whether aluminum, steel or tin, can all be recycled. Larger pieces of metal or coated metal such as pots and pans may need to be taken to a recycling facility."
        views.content.addArrangedSubview(paragraph5)
        let heading4 = createHeading(parentFrame: views.content.bounds)
        heading4.text = "Paper"
        views.content.addArrangedSubview(heading4)
        let paragraph6 = createParagraph(parentFrame: views.content.bounds)
        paragraph6.text = "Most types of paper can be recycled, such as printing paper, newspaper, books, cardboard and magazines. However, treated or coated paper as well as contaminated paper cannot be recycled."
        views.content.addArrangedSubview(paragraph6)
        let heading5 = createHeading(parentFrame: views.content.bounds)
        heading5.text = "Warning"
        views.content.addArrangedSubview(heading5)
        let paragraph7 = createParagraph(parentFrame: views.content.bounds)
        paragraph7.text = "These rules may be different depending on where you live. Always consult your local recycling provider for the most accurate information!"
        views.content.addArrangedSubview(paragraph7)
        views.prevButton.tintColor = tintColor
        views.nextButton.tintColor = tintColor
        adjustVerticalStackViewSize(stackView: views.content)
        return views.slide
    }
    
    private func createFourthSlide() -> UIView {
        let views = createInstructionViews()
        let tintColor = Constants.colors["red"]
        views.slide.backgroundColor = tintColor
        views.title.text = "What is Non-Recyclable?"
        views.image.image = UIImage(named: "JuniorRecycler")
        let paragraph1 = createParagraph(parentFrame: views.content.bounds)
        paragraph1.text = "Organic materials, such as plants, animals, wood, and food waste are not recyclable."
        views.content.addArrangedSubview(paragraph1)
        let paragraph2 = createParagraph(parentFrame: views.content.bounds)
        paragraph2.text = "Fabric, such as rope, clothing, shoes and towels are not recyclable. However, you can still donate old clothes to charities!"
        views.content.addArrangedSubview(paragraph2)
        let paragraph3 = createParagraph(parentFrame: views.content.bounds)
        paragraph3.text = "Ceramics such as plates and ceramic cups are not recyclable."
        views.content.addArrangedSubview(paragraph3)
        let paragraph4 = createParagraph(parentFrame: views.content.bounds)
        paragraph4.text = "Complicated items and small items such as glasses, although made of recyclable materials, cannot be recycled due to high cost."
        views.content.addArrangedSubview(paragraph4)
        let paragraph5 = createParagraph(parentFrame: views.content.bounds)
        paragraph5.text = "As a rule of thumb, if you’re unsure about an item, then you should not put it into the recycling bin."
        views.content.addArrangedSubview(paragraph5)
        let heading1 = createHeading(parentFrame: views.content.bounds)
        heading1.text = "Warning"
        views.content.addArrangedSubview(heading1)
        let paragraph6 = createParagraph(parentFrame: views.content.bounds)
        paragraph6.text = "These rules may be different where you live. Always consult your local recycling provider for the most accurate information!"
        views.content.addArrangedSubview(paragraph6)
        views.prevButton.tintColor = tintColor
        views.nextButton.tintColor = tintColor
        adjustVerticalStackViewSize(stackView: views.content)
        return views.slide
    }
    
    private func createFifthSlide() -> UIView {
        let views = createInstructionViews()
        let tintColor = Constants.colors["yellow"]
        views.slide.backgroundColor = tintColor
        views.title.text = "Special Items"
        views.image.image = UIImage(named: "GreenGuru")
        let paragraph1 = createParagraph(parentFrame: views.content.frame)
        paragraph1.text = "These items are recyclable – with a catch. They cannot be recycled at your curbside bin but may be recyclable at specialized facilities and collection points."
        views.content.addArrangedSubview(paragraph1)
        let heading1 = createHeading(parentFrame: views.content.frame)
        heading1.text = "Electronics"
        views.content.addArrangedSubview(heading1)
        let paragraph2 = createParagraph(parentFrame: views.content.frame)
        paragraph2.text = "Electronics, such as phones and computers, cannot be recycled in the recycling bin. However, there are many recycling facilities and special collection points which can recycle used electronics. Similarly, batteries have specialized recycling points. They should not be disposed in the non-recycling bin as they contain chemicals which may pollute the natural environment."
        views.content.addArrangedSubview(paragraph2)
        let heading2 = createHeading(parentFrame: views.content.frame)
        heading2.text = "Metal"
        views.content.addArrangedSubview(heading2)
        let paragraph3 = createParagraph(parentFrame: views.content.frame)
        paragraph3.text = "Scrap metal can be recycled at a metal recycling facility for cash. Small metal parts, such as screws and nails can also be recycled this way if you have a lot of them. Some metal objects such as cooking pots and pans may have a special coating on them that may need to be removed by a specialized recycling facility before it can be recycled."
        views.content.addArrangedSubview(paragraph3)
        let heading3 = createHeading(parentFrame: views.content.frame)
        heading3.text = "Household appliances"
        views.content.addArrangedSubview(heading3)
        let paragraph4 = createParagraph(parentFrame: views.content.frame)
        paragraph4.text = "Household appliances can be recycled into scrap metal at specialized recycling facilities. Properly disposing household appliances can reduce pollution in the environment."
        views.content.addArrangedSubview(paragraph4)
        let heading4 = createHeading(parentFrame: views.content.frame)
        heading4.text = "Glass"
        views.content.addArrangedSubview(heading4)
        let paragraph5 = createParagraph(parentFrame: views.content.frame)
        paragraph5.text = "Household glass such as glass cups and glass plates cannot put in the curbside recycling bin, but some recycling facilities can process them."
        views.content.addArrangedSubview(paragraph5)
        let heading5 = createHeading(parentFrame: views.content.bounds)
        heading5.text = "Warning"
        views.content.addArrangedSubview(heading5)
        let paragraph6 = createParagraph(parentFrame: views.content.bounds)
        paragraph6.text = "These rules may be different where you live. Always consult your local recycling provider for the most accurate information!"
        views.content.addArrangedSubview(paragraph6)
        views.prevButton.tintColor = tintColor
        views.nextButton.tintColor = tintColor
        adjustVerticalStackViewSize(stackView: views.content)
        return views.slide
    }
    
    private func createSixthSlide() -> UIView {
        let view = createSlideView()
        let posterBackground = UIImageView(image: UIImage(named: "cluster"))
        posterBackground.frame = view.bounds
        posterBackground.contentMode = .scaleAspectFill
        view.addSubview(posterBackground)
        let title = UILabel(frame: CGRect(x: 0, y: margin, width: view.bounds.width, height: titleHeight))
        title.font = UIFont.systemFont(ofSize: 48, weight: .bold)
        title.textAlignment = .center
        title.textColor = Constants.colors["white"]
        title.text = "Are You Ready? Let's Go!"
        view.addSubview(title)
        let modeButton = UIButton()
        modeButton.frame = CGRect(x: view.bounds.width/2 - buttonWidth, y: view.bounds.height - margin - titleHeight - buttonHeight/2, width: buttonWidth*2, height: buttonHeight)
        modeButton.setTitle("Game Mode: \(Constants.gameNames[currentGameMode]!)", for: .normal)
        modeButton.tintColor = Constants.colors["white"]
        modeButton.titleLabel?.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        modeButton.addTarget(self, action: #selector(changeGameMode(sender:)), for: .touchUpInside)
        view.addSubview(modeButton)
        let prevButton = UIButton(type: .roundedRect)
        prevButton.frame = CGRect(x: view.bounds.width/4 - buttonWidth/2, y: view.bounds.height - margin - titleHeight/2 - buttonHeight/2, width: buttonWidth, height: buttonHeight)
        prevButton.layer.cornerRadius = buttonHeight/2
        prevButton.setTitle("Previous", for: .normal)
        prevButton.titleLabel?.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        prevButton.tintColor = Constants.colors["green"]
        prevButton.backgroundColor = Constants.colors["white"]
        prevButton.addTarget(self, action: #selector(retractSlide(sender:)), for: .touchUpInside)
        view.addSubview(prevButton)
        let nextButton = UIButton(type: .roundedRect)
        nextButton.frame = CGRect(x: view.bounds.width/4*3 - buttonWidth/2, y: view.bounds.height - margin - titleHeight/2 - buttonHeight/2, width: buttonWidth, height: buttonHeight)
        nextButton.layer.cornerRadius = buttonHeight/2
        nextButton.setTitle("Start Game", for: .normal)
        nextButton.titleLabel?.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        nextButton.tintColor = Constants.colors["green"]
        nextButton.backgroundColor = Constants.colors["white"]
        nextButton.addTarget(self, action: #selector(startGame(sender:)), for: .touchUpInside)
        view.addSubview(nextButton)
        return view
    }
    
}

// MARK: Functions for switching between the slides
extension InstructionsViewController {
    @objc func advanceSlide(sender: UIButton) {
        currentSlide?.isUserInteractionEnabled = false
        slideIndex += 1
        previousSlide = currentSlide
        let newSlide = functionsToGenerateViews[slideIndex]()
        newSlide.frame = CGRect(x: view.bounds.maxX, y: 0, width: view.bounds.width, height: view.bounds.height)
        view.addSubview(newSlide)
        currentSlide = newSlide
        UIView.animate(withDuration: animationSpeed, delay: 0.0, options: .curveEaseOut, animations: {
            newSlide.frame = self.view.bounds
            self.previousSlide!.frame = CGRect(x: -self.view.bounds.maxX, y: 0, width: self.view.bounds.width, height: self.view.bounds.height)
        }, completion: { (completed: Bool) in
            self.previousSlide?.removeFromSuperview()
        })
    }
    
    @objc func retractSlide(sender: UIButton) {
        currentSlide?.isUserInteractionEnabled = false
        slideIndex -= 1
        previousSlide = currentSlide
        let newSlide = functionsToGenerateViews[slideIndex]()
        newSlide.frame = CGRect(x: -view.bounds.maxX, y: 0, width: view.bounds.width, height: view.bounds.height)
        view.addSubview(newSlide)
        currentSlide = newSlide
        UIView.animate(withDuration: animationSpeed, delay: 0.0, options: .curveEaseOut, animations: {
            newSlide.frame = self.view.bounds
            self.previousSlide!.frame = CGRect(x: self.view.bounds.maxX, y: 0, width: self.view.bounds.width, height: self.view.bounds.height)
        }, completion: { (completed: Bool) in
            self.previousSlide?.removeFromSuperview()
        })
    }
}

// MARK: Functions for starting the game
extension InstructionsViewController {
    @objc func changeGameMode(sender: UIButton) {
        let menu = UIAlertController(title: nil, message: "Choose a new game mode", preferredStyle: .actionSheet)
        for gameMode in Constants.GameTypes.allCases {
            let action = UIAlertAction(title: Constants.gameNames[gameMode]!, style: .default, handler: { (alert: UIAlertAction) in
                self.currentGameMode = gameMode
                sender.setTitle("Game Mode: \(Constants.gameNames[gameMode]!)", for: .normal)
            })
            menu.addAction(action)
        }
        if let popoverController = menu.popoverPresentationController {
            popoverController.permittedArrowDirections = UIPopoverArrowDirection.down
            popoverController.sourceView = sender
            popoverController.sourceRect = CGRect(x: sender.bounds.midX, y: sender.bounds.midY, width: 0, height: 0)
        }
        present(menu, animated: true, completion: nil)
    }
    
    @objc func startGame(sender: UIButton) {
        let recyclingType = currentGameMode.toRecyclingType()
        let recyclingViewController = RecyclingViewController.init(recyclingType: recyclingType)
        self.navigationController?.pushViewController(recyclingViewController, animated: true)
    }
}
