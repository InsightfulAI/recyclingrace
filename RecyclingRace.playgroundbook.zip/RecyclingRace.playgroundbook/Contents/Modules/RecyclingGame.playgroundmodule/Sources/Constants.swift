//
//  Constants.swift
//  recyclingracetest
//
//  Created by Wenzheng Du on 7/4/21.
//

import Foundation
import UIKit

public class Constants {
    
    public enum RecyclingTypes: CaseIterable {
        case recyclable
        case non_recyclable
        case special
        case na
    }
    
    public enum GameTypes: CaseIterable {
        case recyclable
        case non_recyclable
        case special
        case random
        
        public func toRecyclingType() -> RecyclingTypes {
            switch self {
            case .recyclable:
                return RecyclingTypes.recyclable
            case .non_recyclable:
                return RecyclingTypes.non_recyclable
            case .special:
                return RecyclingTypes.special
            case .random:
                let result = Int.random(in: 0..<3)
                if result == 0 {
                    return .recyclable
                } else if result == 1 {
                    return .non_recyclable
                } else {
                    return .special
                }
            }
        }
    }
    
    public static let recyclingNames: [RecyclingTypes: String] = [
        .recyclable: "recyclable",
        .non_recyclable: "non-recyclable",
        .special: "special",
        .na: "other"
    ]
    
    public static let gameNames: [GameTypes: String] = [
        .recyclable: "Recyclable",
        .non_recyclable: "Non-Recyclable",
        .special: "Special",
        .random: "Random"
    ]
    
    public static let objectTypes: [RecyclingTypes:[String]] = [
        .recyclable:[
            "bucket", "carton", "glass_bottle", "pot", "tray", "basket", "file", "plate_rack", "measuring_cup", "crate",
            "soda_bottle", "pencil_sharpener", "water_bottle", "steel_bottle", "jigsaw_puzzle", "mixing_bowl", "petri_dish",
            "milk_can", "newspaper", "paper", "soap_dispenser", "bin", "bottlecap", "lock", "plastic_bottle",
            "book", "metal_can"
        ],
        .non_recyclable:[
            "plant", "rope", "tissue", "bandaid", "hair_slide", "salt_shaker", "candle", "shower_curtain", "piggy_bank",
            "towel", "vegetable", "sock", "helmet", "makeup", "wooden_spoon", "binder", "balloon", "ruler", "diaper", "plate",
            "instrument", "eraser", "matchstick", "bag", "cup", "mask", "pencil_box", "shoe", "doormat", "packet", "paintbrush",
            "teddy", "quilt", "pillow", "broom", "quill", "curtain", "vase", "food", "tent", "fruit", "teapot", "mousetrap", "necklace",
            "wallet", "bowl", "lighter", "fungus", "pen", "dishrag", "handkerchief", "swab", "animal", "sunglasses", "barrel", "whiskey_jug",
            "hat", "clothing",
        ],
        .special:[
            "appliance", "hook", "syringe", "bike", "manhole_cover", "pin", "screw", "car", "chain", "buckle", "grille", "umbrella",
            "ladle", "washer", "electronics", "computer", "cassette", "frying_pan", "coffee_pot", "spring", "lawn_mower", "thimble",
            "phone", "iron", "nail", "plastic_bag", "tool", "cooking_pot", "glass", "goblet", "water_jug"
        ],
        .na:["other", "switch", "tub", "toilet", "sporting_equipment", "bathtub", "furniture", "gun"]
    ]
    
    public static let colors: [String:UIColor] = [
        "green": UIColor(red: CGFloat(0), green: CGFloat(201.0/255.0), blue: CGFloat(59.0/255.0), alpha: CGFloat(1)),
        "yellow": UIColor(red: CGFloat(243.0/255.0), green: CGFloat(170.0/255.0), blue: CGFloat(0), alpha: CGFloat(1)),
        "red": UIColor(red: CGFloat(243.0/255.0), green: CGFloat(47.0/255.0), blue: CGFloat(0), alpha: CGFloat(1)),
        "gray": UIColor(white: CGFloat(101.0/255.0), alpha: CGFloat(1)),
        "white": UIColor.white
    ]
    
    public static let recyclingColors: [RecyclingTypes:String] = [.recyclable:"green", .non_recyclable:"red", .special:"yellow", .na:"gray"]
}
