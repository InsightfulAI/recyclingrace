//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import UIKit
import BookCore
import PlaygroundSupport

PlaygroundPage.current.wantsFullScreenLiveView = true
PlaygroundPage.current.liveView = instantiateLiveView()
//#-end-hidden-code

/*:
 Playground by Wenzheng Du. Submission for WWDC Swift Student Challenge 2021.

 # Before you begin
 
 - Important: Before you begin, please do the following:
 
 * Rotate the iPad to "Landscape Right" orientation, with the USB-C/Lightning port facing the right. Do not rotate the iPad while using this playground.
 
 * Remember to switch off the "Enable Results" option every time before running code. Not doing so may cause the playground to crash.
 
 * Give camera permissions when prompted so the playground may function. The camera is used to identify recyclable objects.
 
 Please follow these instructions for an optimal experience. When you're ready, click the "Run My Code" button to start.
 */
